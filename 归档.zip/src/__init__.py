"""
Multi-UAV Edge Computing Network Optimization
"""

__version__ = "1.0.0"

